#ifndef _ISNUMBER_H_
#define _ISNUMBER_H_

int isnumber(char *string);
#endif


