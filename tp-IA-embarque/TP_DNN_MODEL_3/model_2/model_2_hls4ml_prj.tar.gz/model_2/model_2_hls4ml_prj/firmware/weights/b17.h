//Numpy array shape [1]
//Min -0.058105468750
//Max -0.058105468750
//Number of zeros 0

#ifndef B17_H_
#define B17_H_

#ifndef __SYNTHESIS__
bias17_t b17[1];
#else
bias17_t b17[1] = {-0.0581054687500};
#endif

#endif
