//Numpy array shape [1]
//Min -0.006835937500
//Max -0.006835937500
//Number of zeros 0

#ifndef B17_H_
#define B17_H_

#ifndef __SYNTHESIS__
bias17_t b17[1];
#else
bias17_t b17[1] = {-0.0068359375000};
#endif

#endif
