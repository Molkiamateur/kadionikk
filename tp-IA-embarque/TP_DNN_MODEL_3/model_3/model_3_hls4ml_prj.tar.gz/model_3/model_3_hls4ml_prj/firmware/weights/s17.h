//Numpy array shape [1]
//Min 0.062500000000
//Max 0.062500000000
//Number of zeros 0

#ifndef S17_H_
#define S17_H_

#ifndef __SYNTHESIS__
exponent_type17 s17[1];
#else
exponent_type17 s17[1] = {{1, -4}};
#endif

#endif
