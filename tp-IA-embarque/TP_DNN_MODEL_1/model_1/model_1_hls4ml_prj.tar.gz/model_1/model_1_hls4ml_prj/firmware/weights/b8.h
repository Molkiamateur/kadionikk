//Numpy array shape [1]
//Min -0.019967827946
//Max -0.019967827946
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
Dense_bias_t b8[1];
#else
Dense_bias_t b8[1] = {-0.019968};
#endif

#endif
