//Numpy array shape [1]
//Min -0.064453125000
//Max -0.064453125000
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[1];
#else
bias11_t b11[1] = {0.0000000000000};
#endif

#endif
