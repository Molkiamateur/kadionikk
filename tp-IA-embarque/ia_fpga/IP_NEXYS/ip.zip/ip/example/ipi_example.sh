# ==============================================================
# Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2.1 (64-bit)
# Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
# ==============================================================

/home/labo/Xilinx/Vivado/2019.2/bin/vivado  -notrace -mode batch -source ipi_example.tcl -tclargs xc7a100t-csg324-1 ../xilinx_com_hls_model_nexys_pruned_5_hls4ml_prj_5_1_0.zip
