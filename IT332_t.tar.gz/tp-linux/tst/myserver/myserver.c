#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include "bcm2835.h"
#include "bcm2835.c"
#include "bsp.h"
#include "bsp.c"

int main(argc,argv)
     int argc ;
     char *argv[] ;

{
  int sd;
  struct sockaddr_in sa;		/* Structure Internet sockaddr_in */
  struct hostent *hptr ; 		/* Infos sur le serveur */
  int port;        		/* Numero de port du serveur */

  int newsd;			/* Id de la socket entrante */
  struct sockaddr_in newsa;	/* sockaddr_in de la connection entrante */
  int newsalength;
  struct hostent *newhptr; 	/* Infos sur le client suivant /etc/hosts */

  char buf[2];        		/* Buffer de reception */
  char* ret;
  int n, i;
  char value;


  /* verification du nombre d'arguments de la ligne de commande */
  if (argc != 2) {
    printf("myserver. Erreur d'arguments\n");
    printf("Syntaxe : %% myserver numero_port\n");
    exit(1);
  }

  /* Recuperation numero port passe en argument */
  port = atoi(argv[1]);


  /* Initialisation la structure sockaddr sa avec les infos  formattees : */

  /* Famille d'adresse : AF_INET ici */
  sa.sin_family = AF_INET;

  /* Initialisation du numero du port */
  sa.sin_port = htons(port);

  sa.sin_addr.s_addr = INADDR_ANY;

  /* Creation de la socket TCP */
  if((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    printf("Probleme lors de la creation de socket\n");
    exit(1);
  }

  /* Bind sur la socket */
  if(bind(sd, (struct sockaddr *) &sa, sizeof(sa)) == -1) {
    printf("Probleme avec le bind\n");
    exit(1);
  }

  /* Initialisation de la queue d'ecoute des requetes (5 max) */
  listen(sd, 5); 

  printf("Serveur myserver en ecoute...\n");

  BSP_init();

  while(1) {
    newsalength = sizeof(newsa) ;
    if((newsd = accept(sd, ( struct sockaddr * ) &newsa, &newsalength)) < 0 ) {
      printf("Erreur sur accept\n");
      exit(1);
    }

    read(newsd, buf, 2);
    i = buf[0] - '0';
    n = buf[1] - '0';
    
    if(n == 1){
      BSP_setLED(i);
      ret = "3";
      write(newsd, ret, 1);
    } else if(n == 0){
      BSP_clrLED(i);
      ret = "2";
      write(newsd, ret, 1);
    }else{
      ret = "1";
      write(newsd, ret, 1);
    }
  }
  exit(0);
}
