#include <stdio.h>

int main(){
	printf("Hello wolf\n");
	return 0;
}
