/* hello.c: A standard "Hello, world!" program */
 
#include <stdio.h>
 
int main(int argc, char* argv[])
{
   printf("Hello, world! (cmake)\n");

   return 0;
}
